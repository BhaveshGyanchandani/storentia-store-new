# MAISON — Premium E-Commerce Frontend

A production-quality, portfolio-grade e-commerce frontend built with **TypeScript, React, Vite, Tailwind CSS and shadcn/ui-style components**. Editorial, minimal, and built around a single considered accent color rather than default "AI-generated" SaaS aesthetics.

## Tech Stack

- **React 18** + **TypeScript** + **Vite 5**
- **Tailwind CSS 3** with a custom design-token system (CSS variables for color, radius, shadow)
- **shadcn/ui-style primitives**, hand-built on top of **Radix UI** (Dialog, Tabs, Select, Checkbox, Radio Group, Slider, Accordion, Dropdown Menu, Tooltip, Separator)
- **Framer Motion** for hero, scroll-reveal, gallery and cart micro-interactions
- **React Router v6** for routing
- **Zustand** (with `persist`) for cart and wishlist state, saved to `localStorage`
- **Lucide React** for icons
- **Sonner** for toast notifications

## Features

- Editorial homepage: full-bleed hero, category navigation, trending grid, asymmetric editorial section, new arrivals, promo banner, newsletter
- `/shop` product listing with sidebar filters (desktop) / bottom sheet filters (mobile): category, brand, price range, size, color, rating, availability, plus sort and load-more pagination
- `/product/:id` product detail page: image gallery with thumbnails and transitions, color/size selection, quantity stepper, add-to-bag / buy-now, wishlist, delivery info, accordion details & reviews, related products
- Cart drawer (Sheet) with quantity controls, move-to-wishlist, subtotal/shipping/total, animated badge count
- `/wishlist` page with empty state
- Command-style search (⌘/click to open) with recent + trending searches and live keyboard-navigable results
- `/checkout` with contact, shipping, delivery method, payment method (UPI / Card / COD), promo code, and order summary
- `/order-success` with a tasteful spring-animated confirmation, order number and delivery estimate
- `/account` with sign in/register gate, then Orders / Profile / Addresses / Wishlist tabs
- Informational pages for every footer link (About, Journal, Careers, Sustainability, Contact, Shipping & Returns, FAQ, Size Guide, Privacy, Terms, Accessibility) and a 404 page
- Responsive from 360px to 1440px+, with dedicated mobile nav and filter sheets
- Reduced-motion support, focus-visible states, semantic HTML, accessible Radix primitives throughout

## Project Structure

```
src/
├── components/
│   ├── layout/       # Header, Footer, Layout (page transitions)
│   ├── product/      # ProductCard, ProductGrid, ImageGallery, Rating, RelatedProducts
│   ├── cart/         # CartDrawer, CartItem
│   ├── filters/      # FilterPanel (shared by desktop sidebar + mobile sheet)
│   ├── search/        # SearchCommand (command-style search dialog)
│   └── ui/           # Hand-built shadcn-style primitives (button, sheet, dialog, tabs, select…)
├── pages/             # Route-level pages
├── data/              # Mock product data (24 products), brands, categories, reviews
├── store/             # Zustand cart & wishlist stores
├── hooks/             # useScrollHeader
├── lib/               # cn(), formatPrice(), slugify()
└── types/             # Product, CartLine, Review interfaces
```

## Installation

```bash
npm install
```

## Development

```bash
npm run dev
```

Visit `http://localhost:5173`.

## Build

```bash
npm run build
npm run preview
```

## Mock Data

`src/data/products.ts` contains 24 realistic products across Men, Women, Sneakers, Accessories and Electronics, each with brand, pricing, discount, rating, colors, sizes, description and features. Images use `picsum.photos` seeded placeholders so every image reliably loads — swap these for real product photography or a DAM/CDN URL when connecting a real backend.

### Replacing mock data with a real API

1. Replace the static `PRODUCTS` array and helper functions (`getProductById`, `getRelatedProducts`, `getReviewsForProduct`) in `src/data/products.ts` with API calls (e.g. using `fetch` + React Query or SWR).
2. Keep the `Product`, `CartLine` and `Review` interfaces in `src/types/index.ts` as your contract — update them to match your API schema.
3. Pages currently import from `@/data/products` directly; swap those imports for hooks like `useProduct(id)` / `useProducts(filters)` once you have a data-fetching layer.

### Adding authentication

`src/pages/Account.tsx` currently gates content behind a local `authed` boolean and a mock login/register form. To wire up real auth:

1. Replace the local `useState` with a real auth context/provider (e.g. wrapping `App.tsx`) backed by your auth provider (JWT session, NextAuth-style, Firebase Auth, Auth0, etc.).
2. Submit the login/register forms to your API instead of resolving immediately.
3. Persist the session (httpOnly cookie recommended over localStorage) and read it on load to keep users signed in.
4. Add a route guard (e.g. a `<ProtectedRoute>` wrapper) around `/account` and `/checkout` if you want to require sign-in before checkout.

### Adding payment integration

The checkout page's "Place Order" button currently simulates a network call and navigates to `/order-success` with a mock order number. To integrate real payments:

1. Replace `placeOrder()` in `src/pages/Checkout.tsx` with a call to your backend, which creates an order and a payment intent with your provider (Razorpay/Stripe/etc. — UPI and Card fields are already scaffolded in the UI to match typical Indian checkout flows).
2. Handle the provider's client-side confirmation step (e.g. Razorpay Checkout modal, Stripe `confirmPayment`) before navigating to `/order-success`.
3. Pass the real order ID/total returned by your backend via `navigate("/order-success", { state: { orderNumber, total } })`, as already scaffolded.
4. Clear the cart (`useCartStore.getState().clear()`) only after payment confirmation, not before.

### Deployment

This is a static Vite build (`npm run build` outputs to `dist/`), so it deploys to any static host: Vercel, Netlify, Cloudflare Pages, GitHub Pages, or a plain CDN/S3 bucket. For client-side routing to work on refresh/deep links, configure your host to rewrite all paths to `index.html` (a `_redirects` / `vercel.json` rewrite rule, or Netlify's `netlify.toml`).

## Design Decisions

- **Palette**: warm ivory background, near-black ink text, and a single terracotta/"clay" accent — avoids the generic purple-gradient SaaS look in favor of an editorial, fashion-forward feel.
- **Typography**: Fraunces (serif display) for headlines paired with Manrope (sans) for body text and UI — a deliberate editorial pairing rather than a single default sans font.
- **Motion**: used with intent — staggered hero entrance, scroll-triggered reveals (`whileInView`), product-card hover image swap, spring-based cart badge and order-success check mark, CSS-driven sheet/dialog transitions. Reduced-motion is respected globally.
- **State**: Zustand chosen over Redux for a small, ergonomic API appropriate to this scope; both cart and wishlist persist to `localStorage` so refreshes don't lose state.

## Known Limitations

- This project's mock data uses placeholder imagery (`picsum.photos`) rather than licensed product photography.
- Authentication, payments, and order history are fully mocked on the frontend — see "Adding authentication" / "Adding payment integration" above for how to wire up the real thing.
- `npm install` has not been run in the environment that generated this project (no network access at generation time), so dependencies have not been installed or build-verified end-to-end here. The source was hand-written against each library's documented API and spot-checked with the TypeScript compiler; run `npm install && npm run dev` locally to build and verify.
